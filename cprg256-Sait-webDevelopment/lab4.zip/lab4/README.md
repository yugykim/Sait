
Included with this lab assignment is moshe_safdie.zip. This archive contains a text file of a biography of the Canadian architect and five pictures of his work. 

Create a web page using the pictures and biographical information in the text file. You have some ‘artistic license’ with this assignment. Where appropriate, use borders, margins, padding or any other attributes that enhance the appearance of the web page.

Add some content e.g. subject headings at the start of a paragraph(s). You can also provide captions for any pictures that you use.

Use all of the pictures provided. Refer to the class examples of how to display the pictures as a ‘block’ or ‘grid’ included with the biographical information.

Incorporate a background image to the page. 

Use a ‘Google Font’ or other custom font of your choice.


Submission:

Validate your page using https://validator.w3.org/. When you have completed this, please demonstrate this to your instructor.
Zip up the ‘cprg256/lab4’ directory and upload them to the Brightspace site under Assignments/Lab Assignment 4.