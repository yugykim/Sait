const imageContainer = document.querySelector('#image-container');
const NUMOFIMAGE = 8;
let captionArray = ["Pragser Wildsee, Italy", "Maldive Islands, 马尔代夫", "Beautiful Hotel","Maafushivaru, Maldives", "Hanauma Bay Oahu Hawaii, Honolulu, United States", "Maui County, United States", "Dubai - United Arab Emirates","Prague, Czechia"];

window.onload = () => {
    let imageNumber=2;
    setTimeout(()=>imageContainer.classList.add('fade-in'),500);
    setTimeout(()=>imageContainer.classList.remove('fade-in'),3500);       
    setInterval(()=> {
        setTimeout(()=>imageContainer.classList.add('fade-in'),500);
        setTimeout(()=>imageContainer.classList.remove('fade-in'),3500);       
        let imageTag = `<img src="./img/${imageNumber}.jpg"/>`;
        let captionTag = `<figcaption>${captionArray[imageNumber-1]}</figcaption>`;
        imageContainer.innerHTML = imageTag+captionTag;
        imageNumber++;
        if(imageNumber>NUMOFIMAGE) imageNumber=1;
    },4000);
}


