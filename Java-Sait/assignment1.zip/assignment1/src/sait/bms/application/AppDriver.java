package sait.bms.application;
import java.io.FileNotFoundException;
import sait.bms.managers.*;

public class AppDriver {

	/**
	 * This main method creates a Manage object with default values
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws FileNotFoundException {
		 new Manager();
	}

}
